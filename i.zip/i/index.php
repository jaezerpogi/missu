<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><3</title>
    <style>
        /* Style for the polaroid photo card */
        .polaroid-card {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 220px;
            height: 270px;
            background-color: #fff;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            border: 1px solid #ccc;
            border-radius: 10px;
            cursor: move;
            margin: 20px; /* Add margin between cards */
            user-select: none; /* Disable text highlighting */
        }
        /* Style for the polaroid image */
        .polaroid-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        /* Style for the polaroid caption */
        .polaroid-card p {
            margin: 0;
            font-size: 20px; /* Adjusted font size */
            font-family: Arial, sans-serif; /* Adjusted font family */
            text-align: center;
            font-style: italic; /* Adjusted font style */
            color: #333; /* Adjusted font color */
        }
		
		     /* CSS styles for the round button */
        .round-button {
            display: block;
            width: 60px; /* Adjust button width as needed */
            height: 30px; /* Adjust button height as needed */
            border-radius: 10%; /* Make the button round */
            background-color: #ff6666; /* Set button background color */
            color: #fff; /* Set button text color */
            font-size: 16px; /* Adjust button text size */
            font-weight: bold; /* Make button text bold */
            border: none; /* Remove button border */
            cursor: pointer; /* Change cursor to pointer on hover */
            margin: auto; /* Center the button horizontally */
            position: absolute; /* Position button relative to the polaroid card */
            left: 0; /* Center the button horizontally */
            right: 0; /* Center the button horizontally */
            top: 85%; /* Center the button vertically */
            transform: translateY(-50%); /* Center the button vertically */
        }

        /* Style for video background */
        #background-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover; /* Ensure the video covers the entire viewport */
            z-index: -1;
        }
		
		/* Reset default margin and padding */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
        }
    </style>
</head>
<body>

    <video autoplay muted loop id="background-video">
        <source src="vid.mp4" type="video/mp4">
        <!-- You can add multiple source tags for different video formats -->
        <!-- Example
        <source src="your_video.webm" type="video/webm">
        -->
        Your browser does not support the video tag.
    </video>
	
	<div class="polaroid-card">
    <img src="/img/j7.jpg" alt="Another Image">
    <button class="round-button" onclick="window.location.href = '/i/missu.html';">Open</button>
	</div>

    <div class="polaroid-card">
        <img src="/img/j2.jpg" alt="Another Image">
        <p>at tumingin ka lang sa mata ko </p>
    </div>

    <div class="polaroid-card">
        <img src="/img/j5.jpg" alt="Yet Another Image">
        <p>huwag nang isipin ang mundo</p>
    </div>
	
	<div class="polaroid-card">
        <img src="/img/j3.jpg" alt="Your Image">
        <p>isasayaw ka ng dahan-dahan</p>
    </div>
	
	<div class="polaroid-card">
        <img src="/img/j4.jpg" alt="Your Image">
        <p>aalagaan, kung kailangan</p>
    </div>
	
	<div class="polaroid-card">
        <img src="/img/j6.jpg" alt="Your Image">
        <p>sasaya ka sa aking piling</p>
    </div>
	
	<div class="polaroid-card">
        <img src="/img/j1.jpg" alt="Your Image">
        <p>Kung pipiliin na ibigin</p>
    </div>

    <!-- Add more polaroid cards here -->

    <script>
        // JavaScript for making the polaroid cards movable
        const polaroidCards = document.querySelectorAll('.polaroid-card');

        polaroidCards.forEach(card => {
            let isDragging = false;
            let initialX;
            let initialY;

            // Event listener for mouse down
            card.addEventListener('mousedown', (e) => {
                isDragging = true;
                initialX = e.clientX - card.getBoundingClientRect().left;
                initialY = e.clientY - card.getBoundingClientRect().top;
            });

            // Event listener for mouse move
            window.addEventListener('mousemove', (e) => {
                if (isDragging) {
                    const newX = e.clientX - initialX;
                    const newY = e.clientY - initialY;
                    card.style.left = `${newX}px`;
                    card.style.top = `${newY}px`;
                }
            });

            // Event listener for mouse up
            window.addEventListener('mouseup', () => {
                isDragging = false;
            });
        });
    </script>
</body>
</html>
